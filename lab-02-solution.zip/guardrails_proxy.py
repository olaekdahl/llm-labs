from dotenv import load_dotenv
load_dotenv()

from nemoguardrails import LLMRails, RailsConfig
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()
config = RailsConfig.from_path("rails")
rails = LLMRails(config)

class Query(BaseModel):
    prompt: str

@app.post("/llm")
async def safe_llm(query: Query):
    result = await rails.generate_async(query.prompt)
    print(result)
    return { "command": result.strip() }