import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { getCommandFromLLM } from './llm.js';
import { validateTokenAndPermissions, login } from './auth.js';
import { executeCommand } from './executor.js';

const app = express();
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve static frontend
app.use('/frontend', express.static(path.join(__dirname, 'frontend')));

app.post('/query', async (req, res) => {
  const { query, token } = req.body;
  const command = await getCommandFromLLM(query);
  if (!command) return res.status(400).send('Could not parse query');

  const { valid, reason } = await validateTokenAndPermissions(token, command);
  if (!valid) return res.status(403).send(`Unauthorized: ${reason}`);

  const output = await executeCommand(command);
  return res.json({ output });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const token = login(username, password);
  if (!token) return res.status(401).send('Invalid credentials');
  return res.json({ token });
});

app.listen(3000, () => console.log('LLM Secure Exec running on http://localhost:3000'));