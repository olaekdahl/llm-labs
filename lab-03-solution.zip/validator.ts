const VALID_COMMANDS: Record<string, RegExp> = {
  "ls": /^ls( -[a-zA-Z]+)?( [\w\-/._]+)?$/,
  "df": /^df( -[a-zA-Z]+)?$/,
  "free": /^free( -[a-zA-Z]+)?$/
};

export function validateCommand(command: string): boolean {
  const trimmed = command.trim();
  if (!trimmed) return false;

  const base = trimmed.split(" ")[0];
  if (!base) return false;

  const normalized = base.replace(/[^a-z]/g, "");
  const pattern = VALID_COMMANDS[normalized];

  return pattern ? pattern.test(trimmed) : false;
}
