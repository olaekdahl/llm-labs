import OpenAI from "openai";
import { z } from "zod";
import dotenv from "dotenv";
dotenv.config();

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const ToolCallSchema = z.object({
  tool: z.enum(["list_files", "disk_usage", "memory_usage", "read_file"]),
  args: z.record(z.string()).optional()
});
export const PlanSchema = z.object({
  steps: z.array(ToolCallSchema).min(1).max(5)
});
export type Plan = z.infer<typeof PlanSchema>;

const SYSTEM = `You are a planning agent that outputs ONLY JSON with this shape:
{
  "steps": [
    { "tool": "<one of: list_files|disk_usage|memory_usage|read_file>", "args": { "<k>": "<v>" } }
  ]
}
Do not include explanations or markdown. Prefer minimal steps. If user asks to read files, only do so if a path is provided.`;

export async function planTools(userQuery: string, memorySummary: string): Promise<Plan> {
  const user = `User query: ${userQuery}\n\nContext:\n${memorySummary || "(no memory)"}\n\nReturn JSON only.`;

  const resp = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      { role: "system", content: SYSTEM },
      { role: "user", content: user }
    ],
    temperature: 0
  });

  const text = resp.choices[0]?.message?.content?.trim() || "";
  let parsed: Plan;
  try {
    parsed = PlanSchema.parse(JSON.parse(text));
  } catch {
    parsed = { steps: [{ tool: "disk_usage" }] as any };
  }
  return parsed;
}