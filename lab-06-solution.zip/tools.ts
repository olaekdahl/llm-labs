import { exec as _exec } from "child_process";
import { promisify } from "util";
const exec = promisify(_exec);

export type ToolName = "list_files" | "disk_usage" | "memory_usage" | "read_file";
export type TrustLevel = "low" | "medium" | "high";

export interface ToolCall {
  tool: ToolName;
  args?: Record<string, string>;
}

export interface ToolResult {
  tool: ToolName;
  ok: boolean;
  output?: string;
  error?: string;
}

export interface Tool {
  name: ToolName;
  trust: TrustLevel;
  validate(args?: Record<string, string>): { ok: true } | { ok: false; reason: string };
  run(args?: Record<string, string>): Promise<ToolResult>;
}

function safePath(p?: string): boolean {
  if (!p) return true;
  return /^\/[A-Za-z0-9_\-/.]*$/.test(p) && !p.includes("..");
}
function safeFlag(f?: string): boolean {
  if (!f) return true;
  return /^-[A-Za-z]+$/.test(f);
}

const listFiles: Tool = {
  name: "list_files",
  trust: "low",
  validate(args) {
    if (args?.path && !safePath(args.path)) return { ok: false, reason: "Invalid path" };
    if (args?.flags && !safeFlag(args.flags)) return { ok: false, reason: "Invalid flags" };
    return { ok: true };
  },
  async run(args) {
    const path = args?.path || ".";
    const flags = args?.flags || "-la";
    try {
      const { stdout } = await exec(`ls ${flags} ${path}`.trim());
      return { tool: "list_files", ok: true, output: stdout };
    } catch (e: any) {
      return { tool: "list_files", ok: false, error: e?.message || String(e) };
    }
  }
};

const diskUsage: Tool = {
  name: "disk_usage",
  trust: "medium",
  validate(args) {
    if (args?.flags && !safeFlag(args.flags)) return { ok: false, reason: "Invalid flags" };
    return { ok: true };
  },
  async run(args) {
    const flags = args?.flags || "-h";
    try {
      const { stdout } = await exec(`df ${flags}`.trim());
      return { tool: "disk_usage", ok: true, output: stdout };
    } catch (e: any) {
      return { tool: "disk_usage", ok: false, error: e?.message || String(e) };
    }
  }
};

const memoryUsage: Tool = {
  name: "memory_usage",
  trust: "low",
  validate(args) {
    if (args?.flags && !safeFlag(args.flags)) return { ok: false, reason: "Invalid flags" };
    return { ok: true };
  },
  async run(args) {
    const flags = args?.flags || "-m";
    try {
      const { stdout } = await exec(`free ${flags}`.trim());
      return { tool: "memory_usage", ok: true, output: stdout };
    } catch (e: any) {
      return { tool: "memory_usage", ok: false, error: e?.message || String(e) };
    }
  }
};

const readFile: Tool = {
  name: "read_file",
  trust: "high",   // only admins allowed
  validate(args) {
    if (!args?.path) return { ok: false, reason: "path required" };
    if (!safePath(args.path)) return { ok: false, reason: "Invalid path" };
    return { ok: true };
  },
  async run(args) {
    try {
      const { stdout } = await exec(`tail -n 200 ${args?.path}`);
      return { tool: "read_file", ok: true, output: stdout };
    } catch (e: any) {
      return { tool: "read_file", ok: false, error: e?.message || String(e) };
    }
  }
};

export const TOOL_REGISTRY: Record<ToolName, Tool> = {
  list_files: listFiles,
  disk_usage: diskUsage,
  memory_usage: memoryUsage,
  read_file: readFile
};