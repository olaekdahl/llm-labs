import jwt from 'jsonwebtoken';
import { promises as fs } from 'fs';

const policyDB: Record<string, string[]> = {
  'admin': ['ls -a','ls -la', 'df -h'],
  'viewer': ['ls -a', 'ls -la'],
};

const auditLogPath = './audit.log';

export async function validateTokenAndPermissions(token: string, command: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET as string) as any;
    const role = decoded.role;
    const allowedCommands = policyDB[role] || [];

    const normalizedCommand = command.trim();
    const allowed = allowedCommands.includes(normalizedCommand);

    const entry = `[${new Date().toISOString()}] role=${role} command="${command}" allowed=${allowed}\n`;
    await fs.appendFile(auditLogPath, entry);

    console.log("Decoded role:", role);
    console.log("Command from LLM:", JSON.stringify(command));
    console.log("Allowed commands:", allowedCommands);

    if (!allowed) {
      return { valid: false, reason: 'Insufficient permissions' };
    }

    return { valid: true, reason: 'Allowed command' };
  } catch (err) {
    return { valid: false, reason: 'Invalid or expired token' };
  }
}

export function login(username: string, password: string): string | null {
  const users: Record<string, { password: string, role: string }> = {
    alice: { password: "pass123", role: "admin" },
    bob: { password: "pass123", role: "viewer" }
  };

  const user = users[username];
  if (user && user.password === password) {
    return jwt.sign({ role: user.role }, process.env.JWT_SECRET as string, { expiresIn: "1h" });
  }

  return null;
}