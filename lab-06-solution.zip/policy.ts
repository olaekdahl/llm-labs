import fetch from "node-fetch";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { TrustLevel } from "./tools";

const ToolNameSchema = z.enum(["list_files", "disk_usage", "memory_usage", "read_file"]);
export type ToolName = z.infer<typeof ToolNameSchema>;

const ROLE_TRUST: Record<string, TrustLevel[]> = {
  admin: ["low", "medium", "high"],
  viewer: ["low", "medium"] // cannot run high-trust tools
};

const ROLE_POLICY: Record<string, ToolName[]> = {
  admin: ["list_files", "disk_usage", "memory_usage", "read_file"],
  viewer: ["list_files", "disk_usage", "memory_usage"]
};
export interface PolicyDecision {
  ok: boolean;
  reason?: string;
}

export function checkTrustBoundary(role: string, toolTrust: TrustLevel): PolicyDecision {
  const allowed = ROLE_TRUST[role] || [];
  if (!allowed.includes(toolTrust)) {
    return { ok: false, reason: "Escalation attempt: tool requires higher trust level." };
  }
  return { ok: true };
}

export async function checkPolicyWithNeMo(tool: { tool: ToolName; args?: Record<string, string> }): Promise<PolicyDecision> {
  try {
    const res = await fetch("http://localhost:7000/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: tool.tool })
    });
    const raw = await res.json();
    const data = raw as { validated_command?: string; command?: string };
    const validated = (data.validated_command || data.command || "").trim();
    if (validated === tool.tool) return { ok: true };
    if (validated === "validated") return { ok: true };
    return { ok: false, reason: "Rejected by NeMo policy." };
  } catch (e: any) {
    return { ok: false, reason: `NeMo policy error: ${e?.message || e}` };
  }
}

export function checkRoleToken(token: string, tool: ToolName): PolicyDecision {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET as string) as any;
    const role = decoded.role;
    const allowed = ROLE_POLICY[role] || [];
    if (!allowed.includes(tool)) return { ok: false, reason: "Role not permitted for tool." };
    return { ok: true };
  } catch {
    return { ok: false, reason: "Invalid token." };
  }
}