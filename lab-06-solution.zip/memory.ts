import { TrustLevel } from "./tools";

export interface MemoryItem {
  role: "user" | "assistant" | "system";
  content: string;
  at: number;
  trust?: TrustLevel; 
}

type SessionId = string;
const store = new Map<SessionId, MemoryItem[]>();

export function appendMemory(sessionId: string, item: MemoryItem) {
  const list = store.get(sessionId) ?? [];
  list.push(item);
  const MAX_ITEMS = 20;
  const trimmed = list.slice(-MAX_ITEMS);
  store.set(sessionId, trimmed);
}

export function getMemory(sessionId: string): MemoryItem[] {
  return store.get(sessionId) ?? [];
}

export function summarizeForPrompt(sessionId: string, role: string): string {
  const items = getMemory(sessionId);
  return items
    // filter items based on trust
    .filter(i => {
      if (!i.trust) return true;
      // simple rule: viewer cannot see high-trust memory
      if (role === "viewer" && i.trust === "high") return false;
      return true;
    })
    .map(i => `[${new Date(i.at).toISOString()}] ${i.role}: ${i.content}`)
    .join("\n");
}