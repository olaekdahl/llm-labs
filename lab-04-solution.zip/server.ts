import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { getCommandFromLLM } from "./llm.js";
import { validateTokenAndPermissions, login } from "./auth.js";
import { executeCommand } from "./executor.js";
import { validateCommand } from "./validator.js";
import { planTools } from "./planner.js";
import { getMemory, appendMemory, summarizeForPrompt } from "./memory.js";
import { checkPolicyWithNeMo, checkRoleToken } from "./policy.js";
import { TOOL_REGISTRY, ToolResult, ToolName } from "./tools.js";

const app = express();
app.use(express.json());

app.post("/agent", async (req, res) => {
  try {
    const { query, token, sessionId } = req.body as {
      query: string;
      token: string;
      sessionId?: string;
    };
    const sid = sessionId || "default";

    const summary = summarizeForPrompt(sid);
    const plan = await planTools(query, summary);

    const results: ToolResult[] = [];
    for (const step of plan.steps) {
      appendMemory(sid, {
        role: "assistant",
        content: `Proposed: ${JSON.stringify(step)}`,
        at: Date.now(),
      });

      const toolName = step.tool as ToolName;

      // Role policy
      const roleDecision = checkRoleToken(token, toolName);
      if (!roleDecision.ok) {
        results.push({
          tool: toolName,
          ok: false,
          error: roleDecision.reason ?? "",
        });
        continue;
      }

      // NeMo policy
      const nemoDecision = await checkPolicyWithNeMo({
        tool: toolName,
        args: step.args ?? {},
      });
      if (!nemoDecision.ok) {
        results.push({
          tool: toolName,
          ok: false,
          error: nemoDecision.reason ?? "",
        });
        continue;
      }

      // Argument validation + run
      const impl = TOOL_REGISTRY[toolName];
      const argCheck = impl.validate(step.args);
      if (!argCheck.ok) {
        results.push({
          tool: toolName,
          ok: false,
          error: argCheck.reason ?? "",
        });
        continue;
      }

      const r = await impl.run(step.args);
      results.push(r);

      const content = r.ok
        ? `Tool ${r.tool} ok`
        : `Tool ${r.tool} failed: ${r.error ?? ""}`;
      appendMemory(sid, { role: "assistant", content, at: Date.now() });
    }

    appendMemory(sid, { role: "user", content: query, at: Date.now() });
    return res.json({ plan, results, memory: getMemory(sid) });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || String(e) });
  }
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve static frontend
app.use("/frontend", express.static(path.join(__dirname, "frontend")));

app.post("/query", async (req, res) => {
  const { query, token } = req.body;
  const command = await getCommandFromLLM(query);
  if (!command) return res.status(400).send("Could not parse query");
  if (!validateCommand(command)) {
    return res
      .status(400)
      .json({ error: "Command format rejected by validator" });
  }

  const { valid, reason } = await validateTokenAndPermissions(token, command);
  if (!valid) return res.status(403).send(`Unauthorized: ${reason}`);

  const output = await executeCommand(command);
  return res.json({ output });
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const token = login(username, password);
  if (!token) return res.status(401).send("Invalid credentials");
  return res.json({ token });
});

app.listen(3000, () =>
  console.log("LLM Secure Exec running on http://localhost:3000")
);
