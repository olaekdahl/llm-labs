import { exec } from 'child_process';
import util from 'util';

const execAsync = util.promisify(exec);

export async function executeCommand(command: string): Promise<string> {
  try {
    const { stdout } = await execAsync(command);
    return stdout;
  } catch (err) {
    return 'Command failed';
  }
}